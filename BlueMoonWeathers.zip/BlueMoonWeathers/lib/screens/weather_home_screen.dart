import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/weather_model.dart';
import '../chat_screen.dart';

class WeatherHomeScreen extends StatefulWidget {
  const WeatherHomeScreen({super.key});

  @override
  State<WeatherHomeScreen> createState() => _WeatherHomeScreenState();
}

class _WeatherHomeScreenState extends State<WeatherHomeScreen> {
  final String _apiKey = "741a934a0c1b48f781cc1bc9962c04a4";

  WeatherData?
  _currentWeather; // Starts as null, preventing the constructor error
  bool _isLoading = false;
  bool _isCelsius = true;
  String _errorMessage = "";

  // List of prominent locations in the Philippines
  final List<String> _philippineCities = [
    "Manila",
    "Baguio",
    "Boracay",
    "Siargao",
    "Tagaytay",
    "Cebu City",
    "Davao City",
    "Batanes"
  ];

  late String _selectedCity;

  @override
  void initState() {
    super.initState();
    _selectedCity = _philippineCities[0]; // Defaults to Manila
    _fetchWeather(_selectedCity);
  }

  Future<void> _fetchWeather(String cityName) async {
    setState(() {
      _isLoading = true;
      _errorMessage = "";
    });

    final String url =
        "https://api.openweathermap.org/data/2.5/weather?q=$cityName,PH&units=metric&appid=$_apiKey";

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final Map<String, dynamic> decodedData = jsonDecode(response.body);
        setState(() {
          _currentWeather = WeatherData.fromJson(decodedData);
          _isLoading = false;
        });
      } else {
        setState(() {
          _errorMessage = "Could not fetch data for $cityName.";
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Connection error. Check your internet!";
        _isLoading = false;
      });
    }
  }

  String _getDisplayTemperature() {
    if (_currentWeather == null) return "--";
    if (_isCelsius) {
      return "${_currentWeather!.temperatureCelsius.toStringAsFixed(1)}°C";
    } else {
      double fahrenheit = (_currentWeather!.temperatureCelsius * 9 / 5) + 32;
      return "${fahrenheit.toStringAsFixed(1)}°F";
    }
  }

  String _getDisplayWindSpeed() {
    if (_currentWeather == null) return "--";
    if (_isCelsius) {
      return "${_currentWeather!.windSpeedKmh.toStringAsFixed(1)} km/h";
    } else {
      double mph = _currentWeather!.windSpeedKmh * 0.621371;
      return "${mph.toStringAsFixed(1)} mph";
    }
  }

  Color _getBackgroundColor() {
    if (_currentWeather == null) return Colors.blueGrey;
    switch (_currentWeather!.condition) {
      case WeatherCondition.sunny:
        return Colors.lightBlueAccent.shade100;
      case WeatherCondition.cloudy:
        return Colors.blueGrey.shade200;
      case WeatherCondition.rainy:
        return Colors.grey.shade700;
    }
  }

  IconData _getWeatherIcon() {
    if (_currentWeather == null) return Icons.cloud_queue;
    switch (_currentWeather!.condition) {
      case WeatherCondition.sunny:
        return Icons.wb_sunny_rounded;
      case WeatherCondition.cloudy:
        return Icons.cloud_rounded;
      case WeatherCondition.rainy:
        return Icons.umbrella_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _getBackgroundColor(),
      appBar: AppBar(
        title: Text(_currentWeather != null
            ? "${_currentWeather!.cityName}, PH 🇵🇭"
            : 'BlueMoonWeathers 🌙'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          Row(
            children: [
              Text(_isCelsius ? "°C" : "°F",
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              Switch(
                value: !_isCelsius,
                onChanged: (value) {
                  setState(() {
                    _isCelsius = !value;
                  });
                },
              ),
            ],
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Dropdown Picker
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(15),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedCity,
                  icon: const Icon(Icons.location_on, color: Colors.blue),
                  isExpanded: true,
                  style: const TextStyle(
                      fontSize: 16,
                      color: Colors.black87,
                      fontWeight: FontWeight.bold),
                  items: _philippineCities.map((String city) {
                    return DropdownMenuItem<String>(
                      value: city,
                      child: Text(city),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        _selectedCity = newValue;
                      });
                      _fetchWeather(newValue);
                    }
                  },
                ),
              ),
            ),
            const SizedBox(height: 25),

            if (_isLoading)
              const Expanded(
                  child: Center(
                      child: CircularProgressIndicator(color: Colors.white)))
            else if (_errorMessage.isNotEmpty)
              Expanded(
                  child: Center(
                      child: Text(_errorMessage,
                          style: const TextStyle(
                              color: Colors.redAccent,
                              fontSize: 18,
                              fontWeight: FontWeight.bold))))
            else if (_currentWeather != null) ...[
                Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Icon(_getWeatherIcon(),
                            size: 80,
                            color: _currentWeather!.condition ==
                                WeatherCondition.sunny
                                ? Colors.orange
                                : Colors.blue),
                        const SizedBox(height: 10),
                        Text(
                          _getDisplayTemperature(),
                          style: const TextStyle(
                              fontSize: 48, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          "Wind Speed: ${_getDisplayWindSpeed()}",
                          style: TextStyle(
                              color: Colors.grey.shade600, fontSize: 16),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 25),
                const Text(
                  "PH Context Recommendations",
                  style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
                const SizedBox(height: 10),
                _buildRecommendationCard(),
              ]
          ],
        ),
      ),

      // HERE IS THE FLOATING AI BUTTON INTEGRATION
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            builder: (context) => Padding(
              padding: MediaQuery.of(context).viewInsets,
              child: const WeatherChatScreen(),
            ),
          );
        },
        icon: const Icon(Icons.auto_awesome),
        label: const Text('Ask BlueMoon AI'),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
      ),
    );
  }

  Widget _buildRecommendationCard() {
    if (_currentWeather == null) return const SizedBox.shrink();

    switch (_currentWeather!.condition) {
      case WeatherCondition.sunny:
        return Card(
          color: Colors.amber.shade50,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "☀️ Ang ganda ng gising natin ngayon! It's bright and sunny in ${_currentWeather!.cityName} with ${_getDisplayTemperature()}! Why not step outside for an adventure?",
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.beach_access),
                  label: Text(
                      "Find closest destination near ${_currentWeather!.cityName}"),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber.shade700,
                      foregroundColor: Colors.white),
                )
              ],
            ),
          ),
        );

      case WeatherCondition.cloudy:
        return Card(
          color: Colors.blue.shade50,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              "☁️ Medyo makulimlim ngayon. The sky is looking moody over ${_currentWeather!.cityName}. Perfect time to grab a cold iced coffee or go on a casual walk around town without getting sunburned!",
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
          ),
        );

      case WeatherCondition.rainy:
        return Card(
          color: Colors.blueGrey.shade900,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "🌧️ Tag-ulan Vibes / Cozy Indoors",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
                const SizedBox(height: 6),
                Text(
                  "Buhos ang ulan! Since it's rainy in ${_currentWeather!.cityName}, stay cozy inside! Sit back with a solid book, stream your favorite Filipino movies, or eat some hot Champorado, Sopas, or Ramen.",
                  style: const TextStyle(fontSize: 15, color: Colors.white70),
                ),
                const Divider(color: Colors.white30, height: 20),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.redAccent.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                        color: Colors.redAccent.withValues(alpha: 0.5)),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.umbrella_rounded, color: Colors.redAccent),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "Aalis ka pa rin ba? Huwag kalimutan magdala ng payong (umbrella) or raincoat to stay dry and safe!",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                              fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        );
    }
  }
}