enum WeatherCondition { sunny, cloudy, rainy }

class WeatherData {
  final double temperatureCelsius;
  final WeatherCondition condition;
  final double windSpeedKmh;
  final String
      cityName; // Added to make the app show where the weather is from!

  WeatherData({
    required this.temperatureCelsius,
    required this.condition,
    required this.windSpeedKmh,
    required this.cityName,
  });

  // Factory constructor to turn raw JSON data from OpenWeather into our model
  factory WeatherData.fromJson(Map<String, dynamic> json) {
    // 1. Convert wind speed from meters/sec to km/h (multiply by 3.6)
    double windMps = (json['wind']['speed'] as num).toDouble();
    double windKmh = windMps * 3.6;

    // 2. Map OpenWeather's "main" keyword to our app's internal Enum
    String mainCondition = json['weather'][0]['main'];
    WeatherCondition appCondition;

    if (mainCondition == 'Clear') {
      appCondition = WeatherCondition.sunny;
    } else if (mainCondition == 'Clouds') {
      appCondition = WeatherCondition.cloudy;
    } else if (mainCondition == 'Rain' ||
        mainCondition == 'Drizzle' ||
        mainCondition == 'Thunderstorm') {
      appCondition = WeatherCondition.rainy;
    } else {
      appCondition =
          WeatherCondition.cloudy; // Default fallback for Mist/Snow/etc.
    }

    return WeatherData(
      temperatureCelsius: (json['main']['temp'] as num).toDouble(),
      condition: appCondition,
      windSpeedKmh: windKmh,
      cityName: json['name'],
    );
  }
}
