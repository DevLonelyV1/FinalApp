import 'package:flutter/material.dart';
import 'screens/weather_home_screen.dart'; // Links your entry file to your UI screen
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const BlueMoonWeathersApp());
}

class BlueMoonWeathersApp extends StatelessWidget {
  const BlueMoonWeathersApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BlueMoonWeathers',
      debugShowCheckedModeBanner:
          false, // Removes the red debug banner from the top corner
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.light,
        ),
        useMaterial3: true, // Uses updated modern Material Design 3 guidelines
      ),
      home:
          const WeatherHomeScreen(), // Sets your Philippine weather screen as the starting point
    );
  }
}
